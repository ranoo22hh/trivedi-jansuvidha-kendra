TRIVEDI JANSUVIDHA KENDRA — WEBSITE STARTER
=============================================

Files:
- index.html: bilingual Hindi/English starter website.

CURRENT FEATURES
- Mobile-friendly service information page
- Hindi/English toggle
- WhatsApp contact link
- Print request form that prepares a WhatsApp message
- Uses the contact number 9793402305

IMPORTANT LIMITATION
This starter form does NOT upload or store documents on the website. The customer must attach the document manually in the WhatsApp chat. For actual browser-based file uploads, connect a separate secure form/storage system (for example Google Forms file upload, noting customers may need to sign into Google) or build a backend later.

HOW TO PREVIEW
1. Download and unzip this folder.
2. Open index.html in Chrome to preview it.

HOW TO PUBLISH FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new PUBLIC repository named trivedi-jansuvidha-kendra
3. Upload index.html to the repository root (Add file > Upload files > Commit changes).
4. Open repository Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for the deployment and open the URL shown in Settings > Pages. It usually resembles:
   https://YOUR-USERNAME.github.io/trivedi-jansuvidha-kendra/
   Do not guess the URL; copy the exact one shown by GitHub.

EDIT CONTACT
The number is currently set to 9793402305 and WhatsApp link uses country code 91. To change it, edit both occurrences in index.html.

PRIVACY / SECURITY
Do not ask customers to send passwords, OTPs, PINs, or unnecessary identity documents. Before collecting documents, explain why they are needed and how long you will keep them. Restrict access to customer files.
